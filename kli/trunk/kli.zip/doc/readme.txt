Keyboard Layout Indicator v0.0.

It just indicates current keyboard layout. Where are some appearance
settings assigning by following command line:

kli.exe r,g,b R,G,B B L T

- r,g,b - foreground color
- R,G,B - background color
- B = 0/1 - bold font
- L = 0/1 - lower case
- T = 0/1 - transparent background (if it's '1' then fore and back
  colors must be different)

example:
  kli.exe 0,255,255 0,0,0 1 0 1

* r,g,b / R,G,B - red,green,blue - three decimal numbers, e.g.:
  0,255,255 or 127,0,127.
* don't use any quotes or another delimiters - try to keep described
  format of command line.
* If you have some solutions or found errors - floodway@gmail.com.
  For example, It doesn't work for console windows like 'cmd.exe'.